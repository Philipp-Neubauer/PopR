const OS_NAME = :Windows
function _jl_is_unix(os::Symbol)
if (os==:Windows) return false; 
 elseif (os==:Linux) return true; 
 elseif (os==:FreeBSD) return true; 
 elseif (os==:Darwin) return true; 

else
error("Unknown Operating System")
end
end
