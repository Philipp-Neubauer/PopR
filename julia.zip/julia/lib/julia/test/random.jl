@assert rand() != rand()
