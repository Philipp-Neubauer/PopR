with_output_to_string(@thunk load("perf/perf.jl"))
