  if (!is.numeric(g)){
  if(g=='uniform'){
    g <- rep(1/n,n)
  } else if (g=='poisson') {
    g <- dpois(1:n,pars)
  } else if (g=='negbin') {
    g <- dnbinom(1:n,pars)
  }
}
  # log-stirling number computation is stable to n=120
  s_nk <- function(n,k){
    #    
    kt=0;
    for(m in 0:(n-k))  {
      rt = 0
      for (j in 0:m) rt=rt+(-1)^j*exp((log(j)*(n-k+m))-(lgamma(j+1)+lgamma(m-j+1)))
      kt <- kt + (-1)^m*exp(-(log(n+m)+lgamma(n-k-m+1)+lgamma(n-k+m+1))+log(abs(rt)))}
    return((lgamma(2*n-k+1)-lgamma(k))+log(abs(kt)))
  }
  
  # get stirling numbers
  snk <- matrix(,n,n)
  for (i in 1:n){
    for (j in 1:i){
      snk[i,j]<-exp(s_nk(i,j))
    }
  }
  
  diag(snk) <- 1


 # KL distance
  KL_dist <- function(par,others){
    
    a <-par[1]
    b <-par[2]
    n <- others$n
    g <- others$g
    snk <- others$snk
    
    #integral
    pi_fun <- function(alpha,otros){
      a <-otros$a
      b <-otros$b
      n <- otros$n
      k <- otros$k
      exp((k+a-1)*log(alpha)-b*alpha+lgamma(alpha)-lgamma(alpha+n))
      
    }
    
    KL = 0;pi_k=vector(,n)
    for (k in 1:n){
      nint <- integrate(pi_fun,lower=0,upper=Inf,otros=list(a=a,b=b,k=k,n=n),stop.on.error =F,abs.tol=0.)$value
      pi_k[k] <- ((b^a*snk[n,k])/gamma(a))*nint
      
    }
    pi_k=pi_k/sum(pi_k)
    KL <- sum(g*log(g/pi_k))
    #cat(KL,'\n')
  
    return(KL)
  }

ns=100
seqs = exp(seq(log(1e-5),log(100),l=ns))

KL=matrix(,ns,ns)

a=0;
for (i in seqs){
  a=a+1;cat(a,'\n');b=0;
  for (j in seqs){
    b=b+1;

    KL[a,b] = KL_dist(c(i,j),list(n=n,g=g,snk=snk))
  }
}

KL[which(KL == min(KL,na.rm=T), arr.ind = TRUE) ]
ab=seqs[which(KL == min(KL,na.rm=T), arr.ind = TRUE) ]
a=ab[1]
b=ab[2]
a
b
